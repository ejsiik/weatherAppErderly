package com.example.weatherapp.Models

data class Clouds(
    val all: Int
)