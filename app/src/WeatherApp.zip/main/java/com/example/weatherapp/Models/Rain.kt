package com.example.weatherapp.Models

data class Rain(
    val `1h`: Double
)