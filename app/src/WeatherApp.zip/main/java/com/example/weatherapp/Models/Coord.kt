package com.example.weatherapp.Models

data class Coord(
    val lat: Double,
    val lon: Double
)